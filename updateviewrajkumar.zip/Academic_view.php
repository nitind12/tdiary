<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h1 > Registration Form</h1>
							</div>
							<div class="module-body">
	<form method="post" action="<?php echo site_url('academic_controller/savingdata33');?>" class="form-horizontal row-fluid" id="form102" name="form102">
	<table class="table table-striped table-bordered table-condensed"  border="1">
			<!--<table class="table" >-->
				<thead>
				<tbody>
					<h2>Academic Detail</h2>
								  
									<tr>
									  <td >Last Qualification:<br>
									  	<input type="text" name="qualification_status" class="span8" id="qualification_status" /></td>
									  <td>Passing Year:<br>
									  	<input type="text" id="passing_year" name="passing_year" class="span8"></td>
									  	</tr>
									  	<tr>
									  <td>Name of School:<br>
									  	<input type="text" id="school" name="school" class="span8"></td>
									 
									  	<td>Name of Board:<br>
									  <input type="text"  name="board" class="span8" required="">
									</td>
								</tr>
								<tr>
									
									 
									  	<td>Percentage:<br>
									  <input type="text"  name="percentage" class="span8" required="">
									</td>
								</tr>
								
									
								  </thead>
								</tbody>
								   
								
									
									
								</table><br><br>
								<center>
								<div class="control-group">
											<!--<div class="controls">-->
												
												<button type="submit" class="btn btn-primary" name="save">Save&Next</button>
											<!--</div>-->
										</div></center><br><br>
									</form>
									
</div></div></div></div></div></div>




     