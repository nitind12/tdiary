


<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h1 > Registration Form</h1>
							</div>
							<div class="module-body">
	<form method="post" action="<?php echo site_url('address_form_controller/savingdata31');?>" class="form-horizontal row-fluid" id="form102" name="form102">
	<table class="table table-striped table-bordered table-condensed"  border="1">
			<!--<table class="table" >-->
				<thead>
				<tbody>
					<h2>Address Detail</h2>
								  
									<tr>
									  <td >Address:<br>
									  	<input type="text" name="address" class="span8" id="address" /></td>
									  <td>State:<br>
									  	<input type="text" id="state" name="state" class="span8"></td>
									  	</tr>
									  	<tr>
									  <td>City:<br>
									  	<input type="text" id="city" name="city" class="span8"></td>
									 
									  	<td>pincode:<br>
									  <input type="text"  name="pincode" class="span8" required="">
									</td>
								</tr>
								<tr>
									<td>Date of Commencement:<br>
									  <input type="date"  name="date_of_commencement" class="span8" required="">
									</td>
								</tr>
									
								  </thead>
								</tbody>
								   
								
									
									
								</table><br><br>
								<center>
								<div class="control-group">
											<!--<div class="controls">-->
												
												<button type="submit" class="btn btn-primary" name="save">Save&Next</button>
											<!--</div>-->
										</div></center><br><br>
									</form>
									
</div></div></div></div></div></div>




     