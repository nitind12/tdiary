<div class="span9">
          <div class="content">

            <div class="module">
              <div class="module-head">
                <h1>Registration Form</h1>
              </div>
              <div class="module-body">
                 <div class="btn-box-row row-fluid" >
       
      <div class="btn-box-row row-fluid" >

 
  
      <div class="btn-box-row row-fluid  btn-box big span4"style=" float: left; color: #000090;">
          <a href="<?php echo site_url('Registrationform_controller/index');?>" >
          <div class="btn-box-row row-fluid span2" style="font-size: 11px !important; text-align: center;">

         <b> Student Registration</b>

         
      </div>
     


      </a>
    </div>
     <div class="btn-box-row row-fluid  btn-box big span4"style=" float: left; color: #000090;">
          <a href="<?php echo site_url('Registrationform_controller/index');?>" >
          <div class="btn-box-row row-fluid span2" style="font-size: 11px !important; text-align: center;">

         <b>Faculty<br> 
         Registration</b>

         
      </div>
     
     </div>
   </div>
 </div>
</div>
</div>

</div>




