<div class="span9">
					<div class="content">

						<div class="module">
							<div class="module-head">
								<h1 > Registration Form</h1>
							</div>
							<div class="module-body">
	<form method="post" action="<?php echo site_url('student_reg_controller/savingdata34');?>" class="form-horizontal row-fluid" id="form102" name="form102">
	<table class="table table-striped table-bordered table-condensed"  border="1">
			<!--<table class="table" >-->
				<thead>
				<tbody>
					<h2>College Detail</h2>
								  
									<tr>
									  <td >Course of Admission:<br>
									  	<input type="text" name="course_of_admission" class="span8" id="course_of_admission" /></td>
									  <td>Date Of Admission:<br>
									  	<input type="date" id="date_of_admission" name="date_of_admission" class="span8"></td>
									  	</tr>
									  	<tr>
									  <td>Description:<br>
									  	<input type="text" id="description" name="description" class="span8"></td>
									 
									  	
								</tr>
								
								
									
								  </thead>
								</tbody>
								   
								
									
									
								</table><br><br>
								<center>
								<div class="control-group">
											<!--<div class="controls">-->
												
												<button type="submit" class="btn btn-primary" name="save">Save</button>
											<!--</div>-->
											
										</div></center><br><br>
									</form>
									
</div></div></div></div></div></div>




     