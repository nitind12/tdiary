<div class="span9">
   <div class="module">
      <div class="module-head">
            <h1><?php echo $this->session->userdata('itype');?>

</h1> </div> 
       <div>  
        <?php $this->load->view('Rajkumar/edit_test_marks_view');?>
        </div>

</div>

</div>
</div>
</div>
